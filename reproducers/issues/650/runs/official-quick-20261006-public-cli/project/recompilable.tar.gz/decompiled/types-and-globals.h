#pragma once

//
// This header has been generated using rev.ng.
//

#include "attributes.h"
#include "primitive-types.h"
#include "runtime-library.h"

//
// Types
//

typedef struct _PACKED struct_0 struct_0;
struct _PACKED _SIZE(212) struct_0 {
  uint8_t padding_at_0[212];
};

typedef struct _PACKED struct_1 struct_1;
typedef struct _PACKED struct_2 struct_2;
struct _CAN_CONTAIN_CODE _PACKED _SIZE(50) struct_2 {
  uint8_t padding_at_0[50];
};
struct _CAN_CONTAIN_CODE _PACKED _SIZE(50) struct_1 {
  struct_2 text _STARTS_AT(0);
};

typedef struct _PACKED struct_3 struct_3;
typedef struct _PACKED struct_4 struct_4;
typedef struct _PACKED struct_5 struct_5;
struct _PACKED _SIZE(16) struct_5 {
  uint8_t padding_at_0[16];
};
struct _PACKED _SIZE(16) struct_4 {
  struct_5 public_values _STARTS_AT(0);
};
typedef struct _PACKED struct_6 struct_6;
struct _PACKED _SIZE(4) struct_6 {
  generic32_t public_result _STARTS_AT(0);
};
struct _PACKED _SIZE(20) struct_3 {
  struct_4 data _STARTS_AT(0);
  struct_6 bss _STARTS_AT(16);
};

typedef struct _PACKED artificial_struct_returned_by_rawfunction_7 artificial_struct_returned_by_rawfunction_7;
typedef _ABI(raw_x86)
    artificial_struct_returned_by_rawfunction_7 rawfunction_7(void);

struct _PACKED _SIZE(8) artificial_struct_returned_by_rawfunction_7 {
  pointer_or_number32_t register_eax _STARTS_AT(0);
  pointer_or_number32_t register_edx _STARTS_AT(4);
};

typedef _ABI(SystemV_x86) void cabifunction_9(void);

typedef struct _PACKED struct_12 struct_12;
struct _PACKED _SIZE(8) struct_12 {
  uint8_t padding_at_0[8];
};

typedef struct _PACKED struct_16 struct_16;
struct _PACKED _SIZE(8) struct_16 {
  uint8_t padding_at_0[4];
  generic32_t offset_4;
};

typedef _ABI(SystemV_x86)
    generic32_t cabifunction_17(struct_16 *);

//
// Functions
//

_ABI(SystemV_x86)
generic32_t read_second(struct_16 *argument_0);

_ABI(SystemV_x86)
void _start(void);

//
// Segments
//

struct_0 segment_0;

struct_1 segment_1;

struct_3 segment_2;

//
// Opaque types
//

struct _PACKED _SIZE(1) opaque_type_1 {
  uint8_t padding_at_0[1];
};
typedef struct _PACKED opaque_type_1 opaque_type_1;
struct _PACKED _SIZE(2) opaque_type_2 {
  uint8_t padding_at_0[2];
};
typedef struct _PACKED opaque_type_2 opaque_type_2;
struct _PACKED _SIZE(4) opaque_type_4 {
  uint8_t padding_at_0[4];
};
typedef struct _PACKED opaque_type_4 opaque_type_4;
struct _PACKED _SIZE(8) opaque_type_8 {
  uint8_t padding_at_0[8];
};
typedef struct _PACKED opaque_type_8 opaque_type_8;
struct _PACKED _SIZE(10) opaque_type_10 {
  uint8_t padding_at_0[10];
};
typedef struct _PACKED opaque_type_10 opaque_type_10;
struct _PACKED _SIZE(12) opaque_type_12 {
  uint8_t padding_at_0[12];
};
typedef struct _PACKED opaque_type_12 opaque_type_12;
struct _PACKED _SIZE(16) opaque_type_16 {
  uint8_t padding_at_0[16];
};
typedef struct _PACKED opaque_type_16 opaque_type_16;
struct _PACKED _SIZE(20) opaque_type_20 {
  uint8_t padding_at_0[20];
};
typedef struct _PACKED opaque_type_20 opaque_type_20;
struct _PACKED _SIZE(50) opaque_type_50 {
  uint8_t padding_at_0[50];
};
typedef struct _PACKED opaque_type_50 opaque_type_50;
struct _PACKED _SIZE(212) opaque_type_212 {
  uint8_t padding_at_0[212];
};
typedef struct _PACKED opaque_type_212 opaque_type_212;
