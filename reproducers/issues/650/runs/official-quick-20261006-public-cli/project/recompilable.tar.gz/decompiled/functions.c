#include "types-and-globals.h"
#include "helpers.h"
_ABI(SystemV_x86)
generic32_t read_second(struct_16 *argument_0) {
  struct_16 *var_0 = argument_0;
  return argument_0->offset_4;
}

_ABI(SystemV_x86)
void _start(void) {
  struct_3 *var_0 = &segment_2;
  *(generic32_t *) (generic32_t) ((generic32_t) &segment_2 + 16ULL) = read_second((struct_16 *) &segment_2);
  while ((int8_t) 1) {
  }
}

