#pragma once

//
// This header has been generated using rev.ng.
//

//
// Functions
//

void helper_fldl_ST0_wrapper(void *, generic64_t, generic32_t, generic16_t, generic16_t, generic16_t, generic8_t, generic8_t, generic8_t, generic8_t, generic8_t, generic8_t, generic8_t, generic8_t, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);

generic64_t helper_fstl_ST0_wrapper(void *, generic32_t, generic16_t, generic16_t, generic64_t, generic16_t, generic64_t, generic16_t, generic64_t, generic16_t, generic64_t, generic16_t, generic64_t, generic16_t, generic64_t, generic16_t, generic64_t, generic16_t, generic64_t, generic16_t, generic16_t, generic8_t, generic8_t, generic8_t, generic8_t, generic8_t, generic8_t, generic8_t, generic8_t, void *, void *);

void helper_fpop_wrapper(void *, generic32_t, void *, void *, void *, void *, void *, void *, void *, void *, void *);

generic64_t float64_sub(generic64_t, generic64_t, void *);

generic64_t float64_add(generic64_t, generic64_t, void *);
