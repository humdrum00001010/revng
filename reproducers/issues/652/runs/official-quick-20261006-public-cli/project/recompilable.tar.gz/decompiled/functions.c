#include "types-and-globals.h"
#include "helpers.h"
_ABI(SystemV_x86)
void _start(void) {
  segment_2 = bit_cast(struct_5, 9U);
  while ((int8_t) 1) {
  }
}

