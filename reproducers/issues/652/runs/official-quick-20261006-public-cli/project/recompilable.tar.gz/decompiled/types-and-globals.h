#pragma once

//
// This header has been generated using rev.ng.
//

#include "attributes.h"
#include "primitive-types.h"
#include "runtime-library.h"

//
// Types
//

typedef struct _PACKED struct_0 struct_0;
typedef struct _PACKED struct_1 struct_1;
typedef struct _PACKED struct_2 struct_2;
struct _PACKED _SIZE(12) struct_2 {
  uint8_t padding_at_0[12];
};
struct _PACKED _SIZE(16) struct_1 {
  generic32_t public_selector _STARTS_AT(0);
  struct_2 public_values _STARTS_AT(4);
};
struct _PACKED _SIZE(228) struct_0 {
  uint8_t padding_at_0[212];
  struct_1 rodata _STARTS_AT(212);
};

typedef struct _PACKED struct_3 struct_3;
typedef struct _PACKED struct_4 struct_4;
struct _CAN_CONTAIN_CODE _PACKED _SIZE(18) struct_4 {
  uint8_t padding_at_0[18];
};
struct _CAN_CONTAIN_CODE _PACKED _SIZE(18) struct_3 {
  struct_4 text _STARTS_AT(0);
};

typedef struct _PACKED struct_5 struct_5;
typedef struct _PACKED struct_6 struct_6;
struct _PACKED _SIZE(4) struct_6 {
  generic32_t public_result _STARTS_AT(0);
};
struct _PACKED _SIZE(4) struct_5 {
  struct_6 bss _STARTS_AT(0);
};

typedef struct _PACKED artificial_struct_returned_by_rawfunction_7 artificial_struct_returned_by_rawfunction_7;
typedef _ABI(raw_x86)
    artificial_struct_returned_by_rawfunction_7 rawfunction_7(void);

struct _PACKED _SIZE(8) artificial_struct_returned_by_rawfunction_7 {
  pointer_or_number32_t register_eax _STARTS_AT(0);
  pointer_or_number32_t register_edx _STARTS_AT(4);
};

typedef _ABI(SystemV_x86) void cabifunction_9(void);

//
// Functions
//

_ABI(SystemV_x86)
void _start(void);

//
// Segments
//

struct_0 segment_0;

struct_3 segment_1;

struct_5 segment_2;

//
// Opaque types
//

struct _PACKED _SIZE(1) opaque_type_1 {
  uint8_t padding_at_0[1];
};
typedef struct _PACKED opaque_type_1 opaque_type_1;
struct _PACKED _SIZE(2) opaque_type_2 {
  uint8_t padding_at_0[2];
};
typedef struct _PACKED opaque_type_2 opaque_type_2;
struct _PACKED _SIZE(4) opaque_type_4 {
  uint8_t padding_at_0[4];
};
typedef struct _PACKED opaque_type_4 opaque_type_4;
struct _PACKED _SIZE(8) opaque_type_8 {
  uint8_t padding_at_0[8];
};
typedef struct _PACKED opaque_type_8 opaque_type_8;
struct _PACKED _SIZE(10) opaque_type_10 {
  uint8_t padding_at_0[10];
};
typedef struct _PACKED opaque_type_10 opaque_type_10;
struct _PACKED _SIZE(12) opaque_type_12 {
  uint8_t padding_at_0[12];
};
typedef struct _PACKED opaque_type_12 opaque_type_12;
struct _PACKED _SIZE(16) opaque_type_16 {
  uint8_t padding_at_0[16];
};
typedef struct _PACKED opaque_type_16 opaque_type_16;
struct _PACKED _SIZE(18) opaque_type_18 {
  uint8_t padding_at_0[18];
};
typedef struct _PACKED opaque_type_18 opaque_type_18;
struct _PACKED _SIZE(228) opaque_type_228 {
  uint8_t padding_at_0[228];
};
typedef struct _PACKED opaque_type_228 opaque_type_228;
